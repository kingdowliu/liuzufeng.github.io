== Blog Grid ==

Contributors: dipendahal
Tags: two-columns, right-sidebar, custom-background, custom-colors, custom-menu, featured-images, sticky-post, theme-options, threaded-comments, translation-ready, blog

Requires at least: 4.4
Tested up to: 4.9.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Blog Grid is the Child Theme of Bloge. 


== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

## 1.0.2 - September 14 2018 ##
* Fixed theme uri issue.

## 1.0.1 - September 14 2018 ##
* License issues fixed.

## 1.0.0 - September 14 2018 ##
* Submitted to WordPress

== License ==
Blog Grid is based on Underscores http://underscores.me/, (C) 2012-2014 Automattic, Inc.
Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License Version 2 or later.
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Blog Grid WordPress Theme is a child theme of Bloge, Copyright 2018 Dipen Dahal
Blog Grid is distributed under the terms of the GNU General Public License v2


Bloge WordPress Theme, Copyright 2018 Canyon Themes
Bloge is distributed under the terms of the GNU General Public License v2

== Image used in screenshot ==
https://pixabay.com/en/woman-date-coffee-love-girl-2937216/
https://pixabay.com/en/beauty-coffee-drink-fashion-girl-2605352/
https://pixabay.com/en/dj-deejay-music-nightclub-sound-720589/